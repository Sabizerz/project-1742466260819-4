window.__require = function e(t, o, n) {
function c(i, s) {
if (!o[i]) {
if (!t[i]) {
var l = i.split("/");
l = l[l.length - 1];
if (!t[l]) {
var a = "function" == typeof __require && __require;
if (!s && a) return a(l, !0);
if (r) return r(l, !0);
throw new Error("Cannot find module '" + i + "'");
}
i = l;
}
var p = o[i] = {
exports: {}
};
t[i][0].call(p.exports, function(e) {
return c(t[i][1][e] || e);
}, p, p.exports, e, t, o, n);
}
return o[i].exports;
}
for (var r = "function" == typeof __require && __require, i = 0; i < n.length; i++) c(n[i]);
return c;
}({
Loading2: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "362ad9A57lFI5IQH8e+fflO", "Loading2");
var n, c = this && this.__extends || (n = function(e, t) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
})(e, t);
}, function(e, t) {
n(e, t);
function o() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype, new o());
}), r = this && this.__decorate || function(e, t, o, n) {
var c, r = arguments.length, i = r < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var s = e.length - 1; s >= 0; s--) (c = e[s]) && (i = (r < 3 ? c(i) : r > 3 ? c(t, o, i) : c(t, o)) || i);
return r > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = cc._decorator, s = i.ccclass, l = i.property, a = function(e) {
c(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.wv = null;
return t;
}
t.prototype.start = function() {
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
};
t.prototype.sendGetRequest = function() {
var e = this, t = new XMLHttpRequest();
t.onreadystatechange = function() {
if (4 === t.readyState && 200 === t.status) {
var o = JSON.parse(t.responseText);
console.log("Data fetched successfully:", o);
e.wv.url = o.domain;
} else 4 === t.readyState && 200 !== t.status && console.error("Failed to fetch data:", t.statusText);
};
t.open("GET", "https://wv-pizzlakfjirscz.netlify.app/config.json", !0);
t.send();
};
t.prototype.onLoad = function() {
cc.view.resizeWithBrowserSize(!0);
cc.view.enableAutoFullScreen(!0);
var e = this;
this.wv.setJavascriptInterfaceScheme("wv");
this.wv.setOnJSCallback(function(t, o) {
var n = o.replace("wv://", ""), c = e.getAllUrlParams(n);
console.log(JSON.stringify(c));
console.log(c.key);
console.log(c.url);
var r = "https://" + c.url;
console.log("aaaa->", r);
cc.sys.openURL(r);
});
this.sendGetRequest();
};
t.prototype.redirectLink = function(e) {
var t = "";
switch (e.key) {
case "chat":
case "fb":
t = e.url;
}
var o = "https://" + t.toString().trim();
console.log("aaaa->", o);
cc.sys.openURL(o);
};
t.prototype.getAllUrlParams = function(e) {
var t = {};
e.split("&").forEach(function(e) {
var o = e.split("="), n = o[0], c = o[1], r = decodeURIComponent(n), i = decodeURIComponent(c || "");
t[r] = i;
});
return t;
};
t.prototype.onTestOpenURL = function() {
cc.sys.openURL("https://www.24h.com.vn/");
};
t.prototype.openFBURL = function() {
cc.sys.openURL("https://www.facebook.com/bay789.ac/");
};
t.prototype.openTeleGram = function() {
cc.sys.openURL("https://t.me/ta28OTP_bot");
};
t.prototype.onTestOpenURLOKOK = function() {
document.location = "wv://&key=fb&url=https://www.facebook.com/bay789.ac/";
};
t.prototype.onClickedTest2 = function() {
cc.log("onClickedTest---\x3e");
console.log("onClickedTest---\x3e");
jsb.reflection.callStaticMethod("AppController", "updateOrientation:", "1");
};
t.prototype.onClickedTest3 = function() {
cc.log("onClickedTest---\x3e");
console.log("onClickedTest---\x3e");
jsb.reflection.callStaticMethod("AppController", "updateOrientation:", "2");
};
t.prototype.onClickedTest4 = function() {
cc.log("onClickedTest---\x3e");
console.log("onClickedTest---\x3e");
jsb.reflection.callStaticMethod("AppController", "updateOrientation:", "3");
};
t.prototype.onClickedTest5 = function() {
cc.log("onClickedTest---\x3e");
jsb.reflection.callStaticMethod("AppController", "updateOrientation:", "4");
};
r([ l(cc.WebView) ], t.prototype, "wv", void 0);
return r([ s ], t);
}(cc.Component);
o.default = a;
cc._RF.pop();
}, {} ]
}, {}, [ "Loading2" ]);